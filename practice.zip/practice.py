print("hello world")
# pylint:프로그래밍상에서 잘못된 부분을 미리 알려주는거

#자료형
# print(5)
# print('풍선')
# print("ㅋ"*9)
# print(not 5>10)

#변수
# animal="강아지"
# name="토리"
# age=4
# is_adult=age>=3
# print("우리집" + animal + "는 " + name + "에요")
# # print( str(age) + "살 이구요, 어른일까요? " + str(is_adult))
# print( age, "살 이구요, 어른일까요? ", is_adult)
# #,엔 빈칸이 생긴다

# station="사당"
# print(station,"행 열차가 들어오고 있습니다.")
# File > Preferences > terminal font로 설정
# print(1+1)
# print(2**3) #2의 3승
# print(5%2) #나머지
# print(5//3) #몫

# print(4<=6)
# print(3==3)
# print(3+4==7)
# print(1!=3)

# print((3>0) and (3<5)) # &
# print((3>0) or (5<3)) # ||

# number = 10
# print(number)
# number+=2
# print(number)
# number-=2
# print(number)
# number*=2
# print(number)
# number/=2
# print(number) # 10.0 이 됨

# abs(-5)
# pow(4,2)
# max(5,12)
# min(1,3)
# round(3.14)
# round(3.74)

# from math import *  #math안의 모든걸 import하겠다.

# print(floor(4.99)) #내림
# print(ceil(4.99)) #올림
# print(sqrt(4)) #제곱근 2.0

# from random import *

# print( random() )
# print( int(43*random()) ) #0~43미만의 값
# print(randrange(1,43)) #0~43미만의 값 == randint(0,42)

# date=int(25*random())+4

sentence = '나는 소년'
print(sentence)
sentence2 = "나는 소년"
print(sentence2)
sentence3 = """
나는 모르겠다
어떻게 해야할지
"""
print(sentence3)

jumin = "980715-1456312"
print("성별 : "+ jumin[7] ) #성별 : 1
print("연 :"+ jumin[0:2] ) #0이상 2미만 까지 가져옴.
print("일 :"+ jumin[4:6] ) 

print("생년월일 :"+jumin[:6] ) #처음부터 6미만까지.
print("뒤 7자리 :"+jumin[7:] ) #7부터 끝까지.
print("뒤 7자리(뒤에서 부터 계산) :"+jumin[-7:] )
# 맨 뒤에서 7번째부터 끝까지

python = "Python Is Amazing"
print(python.lower()) #소문자화
print(python.upper()) #대문자화
print(python[0].isupper()) #대문자인지 Boolean
print(len(python)) #문자열길이

print(python.replace("Python", "Java")) #Python을 Java로 바꿈


index = python.index("n")
print(index) #5 출력

index = python.index("n", index + 1) #아까찾은 n다음부터 n 검색
print(index) #15 출력

print(python.find("Java")) #똑같이 찾는거. Java는 없으니까 -1출력
# print(python.index("Java")) #index는 검색 문자열이 없으면 오류.

#문자열 포맷
#방법 1
print("나는 %d살 입니다." % 20) # %d자리에 20 들어감.
print("나는 %s가 좋아요" % "자바") #문자열 
print("내 학점은 %c 입니다" % "F") #한 문자
# %s 는 문자열, 한문자, 숫자 다 상관없다
print("나는 %s 색과 %s색을 좋아해요" % ("파란", "빨간"))

# 방법 2
print("나는 {}살입니다.".format(20))
print("나는 {}색과 {}색을 좋아함".format("파란","빨간"))
print("나는 {1}색과 {0}색을 좋아함".format("파란","빨간")) #앞이 빨간, 뒤가 파란이 된다.
#방법 3
print("나는 {age}색과 {color}색을 좋아함".format(age =20, color="red"))

#방법 4 (v3.6이상~)
age=20
color="red"
print(f"나는{age}살이고 I like {color}.") #f를 앞에 붙여서 변수사용

#\n : 줄바꿈
print("나를알고 적을알면 지피지기")
print("나를알고 \"적을알면\" 지피지기") # 역슬래쉬로 기호들 사용
print("RedApple \rPine") # \r : 커서를 맨앞으로 이동
print("RedApple\bPine") # \b : 백스페이스  한 글자 삭제 \t는 탭

#리스트 []

# 지하철 칸별로 10명, 20명, 30명
# subway1 = 10
# subway2 = 20
# subway3 = 30

subway = [10, 20, 30]
print(subway) # [10,20,30]
subway=["나", "너", "우리"]
print( subway.index("우리") )

# 하하씨가 다음 정류장에서 다음 칸에 탐
subway.append("하하") #append는 맨뒤에 하나 추가.
subway.insert(1, "정형돈") #정형돈을 1번째 위치에 추가.

wholeave = subway.pop() #제일 뒤에 있는게 빠짐. 빠진사람이 할당

subway.append("나")
print(subway.count("나")) # 2
#정렬도 가능
num_list=[5,2,4,3,1]
num_list.sort() # 1,2,3,4,5로 정렬.
num_list.reverse() #5,4,3,2,1로 바뀜.
# num_list.clear()  다 지워짐ㅠㅠ
mix_list=["조세호", 20, True] # 자료형에 관계없이 가능

#리스트 확장
num_list.extend(mix_list) # 리스트 두개가 합쳐진다

#사전 만들기!
cabinet = { 3:"유재석", 100:"김태호" }  # key, 콜론, value
print(cabinet[3]) #유재석이 출력.
print( cabinet.get(3) ) #위랑 같다.
# print(cabinet[5]) # KeyError[5]라는 오류 출력 후 바로 프로그램 종료.
print( cabinet.get(5) ) #None 이 출력. 종료 안됨.
print( cabinet.get(5, "사용가능") ) #사용가능 이 출력.

print(3 in cabinet) # True
print(6 in cabinet) # Flase

mycabinet = {"A-3":"내꺼", "B-100":"니꺼"}
mycabinet["C-20"] = "조세호" #끝에 C-20이라는 Key를 만들고 조세호를 넣는다. C-20이 이미 있으면 값이 업데이트.

# 간 손님
del mycabinet["A-3"] #A-3키를 삭제
print(mycabinet.keys()) #키들만 출력
print(mycabinet.values()) #값들만 출력
print(mycabinet.items()) #쌍으로 출력. clear로 다 없애기

#튜플 list와는 다르게 내용 변경이나 추가를 할 수 없지만 속도가 list보다 빠르다.
menu=("돈까스", "치즈까스")
print(menu[0])
print(menu[1])

# menu.add("생선까스") #튜플은 추가가 불가능
name = "김종국"
age = 20
hobby = "코딩"

( name, age, hobby ) = ("김종국", 20, "코딩")
print(name,age,hobby) 

#집합 set, 중복안됨, 순서 없음
my_set = {1,2,3,3,3}
print(my_set) # {1,2,3}

java = {"유재", "조세", "박명"}
python = set(["유재", "박명"])
# 교집합
print( java & python) # 유재
print( java.intersection(python)) # 유재

# 합집합
print(java | python)
print(java.union(python))

# 차집합 java는 가능, python은 불가능
print(java - python)
print(java.difference(python)) #조세, 박명
java.remove("박명")

#자료구조의 변경
menu = {"커피", "우유", "주스"}
print(menu, type(menu)) #{커피, 우유, 주스} , <class 'set'>

menu = list(menu) #list로 바뀜 []
menu = tuple(menu) #tuple로 바뀜 ()

weather = "비"

if weather == "비" or weather == "눈": #or
    print("우산을 챙기세요")
elif weather == "미세먼지":
    print("마스크 챙겨")
else:
    print("it's good")

weather = input("오늘 날씨는?") #입력을 기다린다.

temp = int(input("기온은 어때요?")) #input은 문자열으로 받기 때문에 받아서 int로 바로 저장
if 30<=temp:
    print("don't go out")
elif 10 <= temp and temp <30 : # and
    print("It's so so")
elif 0 <= temp < 10: # and
    print(" little cold ")
else:
    print("춥당")

#for 반복문
print("대기번호 : 1")

for waiting_num in [0,1,2,3,4] : 
    print("대기번호 : {0}".format(waiting_num)) #0, 1,2,3,4 순서대로 들어감

for waiting_num in range(1, 5) : # 1에서부터 5미만까지 
    print("대기번호 : {0}".format(waiting_num)) #1,2,3,4 순서대로 들어감

starbucks = ["재석", "박명", "조세"]
for customer in starbucks:
    print("{0}, 커피 준비됨".format(customer))

# while 반복문
customer = "토르"
index = 5
while index >= 1 :
    print("{0}, 커피 준비됨. {1}번안에 와라".format(customer, index))
    index -= 1
    if index==0:
        print("커피 버렸어요")

customer = "토르"
person = "Unknown"

while person != customer:
    print("{0}, 커피 준비됨.".format(customer))
    person = input("이름이 어떻게 되세요? ") # 토르면 종료됨










